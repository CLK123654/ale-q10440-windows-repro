# 对象生命周期计划材料

object_inventory.csv按采集顺序保存对象清单，retention_policy.json定义评估日、桶级保留期、CDN要求和批次参数，legal_holds.csv保存法务冻结记录。starter/build_purge_batches.mjs是待完成程序。

完成程序保存到output/src/build_purge_batches.mjs。在input_data目录运行npm run process，入口使用当前node.exe处理材料，并在output生成对象决策、CDN清理批次、回收汇总和计划manifest。全部数据均为脱敏演练材料，处理过程不访问对象存储、CDN或法务工单系统。
