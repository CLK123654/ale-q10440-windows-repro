import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const inputRoot=path.resolve(process.argv[2]??'.');
const outputRoot=path.resolve(process.argv[3]??path.join(path.dirname(inputRoot),'output'));
const programPath=fileURLToPath(import.meta.url);
function parseCsv(text){const rows=[];let row=[],cell='',quoted=false;for(let i=0;i<text.length;i++){const c=text[i];if(quoted){if(c==='"'&&text[i+1]==='"'){cell+='"';i++;}else if(c==='"')quoted=false;else cell+=c;}else if(c==='"')quoted=true;else if(c===','){row.push(cell);cell='';}else if(c==='\n'){row.push(cell.replace(/\r$/,''));if(row.some(v=>v!==''))rows.push(row);row=[];cell='';}else cell+=c;}if(cell!==''||row.length){row.push(cell.replace(/\r$/,''));rows.push(row);}const headers=rows.shift();return rows.map(values=>Object.fromEntries(headers.map((header,index)=>[header,values[index]??''])));}
function csvCell(value){const text=String(value??'');return /[",\r\n]/.test(text)?`"${text.replaceAll('"','""')}"`:text;}
function toCsv(headers,rows){return `${headers.join(',')}\n${rows.map(row=>headers.map(header=>csvCell(row[header])).join(',')).join('\n')}\n`;}
function uniqueSorted(values){return[...new Set(values.filter(Boolean))].sort();}
function ageDays(asOfDate,modified){return Math.floor((Date.parse(`${asOfDate}T00:00:00Z`)-Date.parse(modified))/86400000);}

const inventory=parseCsv(await fs.readFile(path.join(inputRoot,'object_inventory.csv'),'utf8')).map((row,index)=>({...row,inventory_index:index+1,bytes:Number(row.bytes)}));
const policy=JSON.parse(await fs.readFile(path.join(inputRoot,'retention_policy.json'),'utf8'));
const holds=parseCsv(await fs.readFile(path.join(inputRoot,'legal_holds.csv'),'utf8'));
if(!/^\d{4}-\d{2}-\d{2}$/.test(policy.as_of_date)||!Number.isInteger(policy.cdn_purge?.max_paths_per_batch)||policy.cdn_purge.max_paths_per_batch<1||policy.cdn_purge.preserve_inventory_order!==true)throw new Error('CDN批次策略无效');
const rules=new Map(policy.bucket_rules.map(rule=>[rule.bucket,rule]));
const duplicateObjectKeyCount=inventory.length-new Set(inventory.map(row=>row.object_key)).size;
const unknownBucketCount=inventory.filter(row=>!rules.has(row.bucket)).length;
if(duplicateObjectKeyCount||unknownBucketCount)throw new Error('对象主键重复或桶规则缺失');
const activeHolds=new Map();for(const hold of holds){if(!hold.expires_on||hold.expires_on>=policy.as_of_date)activeHolds.set(hold.object_key,hold);}
const decisions=[];
for(const item of inventory){
  const rule=rules.get(item.bucket);const candidateAge=ageDays(policy.as_of_date,item.last_modified_utc);const eligible=candidateAge>=Number(rule.delete_after_days);const hold=activeHolds.get(item.object_key);
  let decision='kept_recent',reason='retention_window';
  if(eligible&&item.active_pointer==='yes'){decision='suppressed';reason='active_pointer';}
  else if(eligible&&hold){decision='suppressed';reason='legal_hold_active';}
  else if(eligible&&rule.requires_cdn_purge&&!item.cdn_path){decision='suppressed';reason='cdn_path_missing';}
  else if(eligible&&rule.requires_cdn_purge){decision='purge_then_delete';reason='cdn_purge_required';}
  else if(eligible){decision='delete_without_cdn';reason='retention_expired';}
  decisions.push({inventory_index:item.inventory_index,object_key:item.object_key,bucket:item.bucket,owner_service:item.owner_service,decision,reason,hold_id:reason==='legal_hold_active'?hold.hold_id:'',hold_expires_on:reason==='legal_hold_active'?hold.expires_on:'',cdn_path:item.cdn_path,purge_batch_id:'',bytes:item.bytes,candidate_age_days:candidateAge});
}
const purgeDecisions=decisions.filter(row=>row.decision==='purge_then_delete');const batches=[];const limit=policy.cdn_purge.max_paths_per_batch;
for(let offset=0;offset<purgeDecisions.length;offset+=limit){const slice=purgeDecisions.slice(offset,offset+limit);const batchId=`${policy.cdn_purge.batch_prefix}-${String(batches.length+1).padStart(3,'0')}`;for(const row of slice)row.purge_batch_id=batchId;batches.push({batch_id:batchId,action:'cdn_purge_before_delete',path_count:slice.length,paths:slice.map(row=>row.cdn_path),object_keys:slice.map(row=>row.object_key),owner_services:uniqueSorted(slice.map(row=>row.owner_service)),estimated_reclaim_bytes:slice.reduce((sum,row)=>sum+row.bytes,0)});}
const actionOrder=['purge_then_delete','delete_without_cdn','suppressed','kept_recent'];
const summaries=actionOrder.map(action=>{const rows=decisions.filter(row=>row.decision===action);return{action,object_count:rows.length,total_bytes:rows.reduce((sum,row)=>sum+row.bytes,0),purge_batch_count:action==='purge_then_delete'?batches.length:0,owner_services:uniqueSorted(rows.map(row=>row.owner_service)).join('|')};});
const sumFor=action=>summaries.find(row=>row.action===action);
const activeHoldCount=holds.filter(row=>!row.expires_on||row.expires_on>=policy.as_of_date).length;
const expiredHoldCount=holds.length-activeHoldCount;
const manifest={result:'PASS',as_of_date:policy.as_of_date,max_paths_per_batch:limit,inventory_rows:inventory.length,eligible_purge_objects:purgeDecisions.length,eligible_delete_without_cdn_objects:sumFor('delete_without_cdn').object_count,suppressed_objects:sumFor('suppressed').object_count,kept_recent_objects:sumFor('kept_recent').object_count,decision_rows:decisions.length,purge_batch_count:batches.length,purge_path_count:purgeDecisions.length,planned_reclaim_bytes:sumFor('purge_then_delete').total_bytes+sumFor('delete_without_cdn').total_bytes,suppressed_bytes:sumFor('suppressed').total_bytes,kept_recent_bytes:sumFor('kept_recent').total_bytes,active_legal_hold_count:activeHoldCount,expired_legal_hold_count:expiredHoldCount,active_pointer_suppressed_count:decisions.filter(row=>row.reason==='active_pointer').length,cdn_path_missing_suppressed_count:decisions.filter(row=>row.reason==='cdn_path_missing').length};
await fs.mkdir(outputRoot,{recursive:true});
await fs.mkdir(path.join(outputRoot,'src'),{recursive:true});
const deliveredProgramPath=path.join(outputRoot,'src','build_purge_batches.mjs');
if(path.resolve(programPath)!==path.resolve(deliveredProgramPath))await fs.copyFile(programPath,deliveredProgramPath);
await fs.writeFile(path.join(outputRoot,'purge_batches.jsonl'),`${batches.map(row=>JSON.stringify(row)).join('\n')}\n`);
await fs.writeFile(path.join(outputRoot,'retention_decisions.csv'),toCsv(['inventory_index','object_key','bucket','owner_service','decision','reason','hold_id','hold_expires_on','cdn_path','purge_batch_id','bytes','candidate_age_days'],decisions));
await fs.writeFile(path.join(outputRoot,'reclaim_summary.csv'),toCsv(['action','object_count','total_bytes','purge_batch_count','owner_services'],summaries));
await fs.writeFile(path.join(outputRoot,'batch_manifest.json'),`${JSON.stringify(manifest,null,2)}\n`);
